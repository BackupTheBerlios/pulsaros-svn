#!/bin/sh

#
# plugin.sh - Script to activate/deactivate/install and configure the plugin
#

PLUGIN_HOME=/coreroot/applications/firefly

